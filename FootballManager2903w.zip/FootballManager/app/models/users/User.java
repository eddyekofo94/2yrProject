package models.users;

import java.util.*;
import javax.persistence.*;

import play.data.validation.*;
import com.avaje.ebean.*;


@Entity
// Map inherited classes to a single table
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
// This is a Customer of type admin
@DiscriminatorValue("user")

// Customer inherits from the SuperUser class

public class User extends SuperUser {


    @OneToOne
    public Long teamID;

    public User() {

    }

    public User(String userID, String password, String name, String loginName) {

        super(userID, password, name, loginName);
//        this.userID = userID;
//        this.password = password;
//        this.name = name;
//        this.loginName = loginName;
    }

//    public static Finder<String, User> find = new Finder<String, User>(String.class, User.class); //Not Ure

    //Generic query helper for entity SuperUser with unique id String
    public static Finder<String,User> find = new Finder<String,User>(User.class);

    public static List<User> findAll(){

        return User.find.all();
    }


    // Check if a user is logged in (by id - email address)
    public static User getLoggedIn(String id) {
        if (id == null)
            return null;
        else
            // Find user by id and return object
            return find.byId(id);
    }


    // Check if a user is logged in (by id - email address)
//    public static User getLoggedIn(String id) {
//        if (id == null)
//            return null;
//        else
//            // Find user by id and return object
//            return find.byId(id);
//    }

   
//  public static User authenticate(String userID, String password){
//       return find.where().eq("userID", userID).eq("password", password).findUnique();
//   }
//
//  public static User getLoggedIn(String id){
//     if(id == null)
//          return null;
//
//      else
//          return find.byId(id);
//   }
}