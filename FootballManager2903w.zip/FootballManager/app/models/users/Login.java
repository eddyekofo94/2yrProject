package models.users;

import models.users.SuperUser;

public class Login{
    public String userID;
    public String password;
    
    public String validate(){
        if(SuperUser.authenticate(userID, password) == null){
            return "Invalid user or password";
        }
        else{
            return null;
        }
    }
}


